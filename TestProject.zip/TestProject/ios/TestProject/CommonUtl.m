//
//  CommonUtl.m
//  MyProject
//
//  Created by CMWA-Levi on 2023/11/8.
//

#import "CommonUtl.h"

@implementation CommonUtl

RCT_EXPORT_MODULE()

RCT_EXPORT_METHOD(tips:(RCTResponseSenderBlock)callback)
{
  callback(@[@"Hellow，This is Mask"]);
}

@end

