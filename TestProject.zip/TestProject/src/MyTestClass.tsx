import React from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {NativeModules} from 'react-native';
import {Observer} from 'mobx-react';
import {configure, observable} from 'mobx';
import SubImageView from './compontents/SubImageView';
configure({
  enforceActions: "never",
})
const CommonUtls = NativeModules.CommonUtl;

const store = observable({showMask: false, tips: ''});

export interface IMyTestClassViewProps {}

export default class MyTestClassView extends React.PureComponent<IMyTestClassViewProps> {
  constructor(props: IMyTestClassViewProps) {
    super(props);
    this.handleTap = this.handleTap.bind(this);
  }
  handleTap = (state: Boolean) => {
    store.showMask = !state;
    if (store.showMask) {
      CommonUtls.tips((tipStr: string) => {
        store.tips = tipStr || '';
      });
    }
  };

  render(): React.ReactNode {
    return (
      <View style={styles.container}>
        <Text>Class组件</Text>
        <Observer
          render={() => (
            <SubImageView
              showMask={store.showMask}
              tips={store.tips}
              handleTap={this.handleTap}
            />
          )}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
