import React from 'react';
import {
  TouchableWithoutFeedback,
  StyleSheet,
  Image,
  View,
  Text,
} from 'react-native';

interface IMyTestProps {
  showMask: boolean;
  tips: string;
  handleTap: (state: boolean) => void;
}

export default function SubImageView(props: IMyTestProps): JSX.Element {
  return (
    <View style={styles.sectionContainer}>
      {props.showMask ? (
        <View>
          <TouchableWithoutFeedback onPressIn={() => props.handleTap(true)}>
            <Image
              style={styles.imageStyle}
              source={require('../../assets/mask.jpeg')}
              resizeMode="contain"
            />
          </TouchableWithoutFeedback>
          <Text style={styles.tip}>{props.tips}</Text>
        </View>
      ) : (
        <TouchableWithoutFeedback onPressIn={() => props.handleTap(false)}>
          <Image
            style={styles.imageStyle}
            resizeMode="contain"
            source={require('../../assets/origin.png')}
          />
        </TouchableWithoutFeedback>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  sectionContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageStyle: {
    width: 200,
    height: 200,
  },
  tip: {
    fontSize: 16,
    color: 'red',
  },
});
