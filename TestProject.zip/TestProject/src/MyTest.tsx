import React from 'react';
import {useState} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {NativeModules} from 'react-native';
import SubImageView from './compontents/SubImageView';

const CommonUtls = NativeModules.CommonUtl;

export default function MyTest(): JSX.Element {
  const [showMask, setShowMask] = useState(false);
  const [tips, setTips] = useState('');

  const handleTap = (state: Boolean) => {
    const show = !state;
    setShowMask(show);
    if (show) {
      CommonUtls.tips((tipStr: string) => {
        setTips(tipStr);
      });
    }
  };

  return (
    <View style={styles.container}>
      <Text>函数组件</Text>
      <SubImageView showMask={showMask} tips={tips} handleTap={handleTap} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
